<?php
include_once('../database/dbconnect.php');

	function submit_general(){

		$queryse="select * from session where id=1";
$runs=mysql_query($queryse);
while($rowse=mysql_fetch_array($runs)){

	$session=$rowse['surrent_session'];
}

 $name=$_POST['name'];
 $year=$session;
 $course=$_POST['course'];
 $stream=$_POST['stream'];
 $branch=$_POST['branch'];
 $father=$_POST['father'];
 $mothername=$_POST['mothername'];
 $mobile_student=$_POST['mobile_student'];
 $mobile_parents=$_POST['mobile_parents'];
 $nature_admission=$_POST['nature_admission'];
 $address1=$_POST['address1'];
 $email=$_POST['email'];
 $admission_date=$_POST['admission_date'];
 $date1=date("y-m-d");
 $date2=$_POST['dob'];
 $dob=date("Y-m-d",strtotime($date2));
 $aadhaar =$_POST['aadhaar'];
 $rollno =$_POST['rollno'];
 $father_occupation=$_POST['father_occupation'];
 $admission_office=$_POST['admission_office'];
 $admission_through=$_POST['admission_through'];
 $bus_opted=$_POST['bus_opted'];
 $hostel_opted=$_POST['hostel_opted'];
  $stucat=$_POST['stucat'];
 $admission_category=$_POST['admission_category'];
 /*$qul_tenth_school1="10th";
 $qul_tenth_school=$_POST['qul_tenth_school'];
 $branch=$_POST['branch'];
 $qul_tenth_board=$_POST['qul_tenth_board'];
 $qul_tenth_yearpassing=$_POST['qul_tenth_yearpassing'];
 $qul_tenth_percentage=$_POST['qul_tenth_percentage'];
 $qul_tenth_pcm=$_POST['qul_tenth_pcm'];
 $qul_twelth_school1="12th";
 $qul_twelth_school=$_POST['qul_twelth_school'];
 $qul_twelth_board=$_POST['qul_twelth_board'];
 $qul_twelth_yearpassing=$_POST['qul_twelth_yearpassing'];
 $qul_twelth_percentage=$_POST['qul_twelth_percentage'];
 $qul_twelth_pcm=$_POST['qul_twelth_pcm'];
 $qul_graduation_school1="graduation";
 $qul_graduation_school=$_POST['qul_graduation_school'];
 $qul_graduation_board=$_POST['qul_graduation_board'];
 $qul_graduation_passingyear=$_POST['qul_graduation_passingyear'];
 $qul_graduation_percentage=$_POST['qul_graduation_percentage'];
 $qul_graduation_pcm=$_POST['qul_graduation_pcm'];
 $qul_diploma_school1="Diploma";
 $qul_diploma_school=$_POST['qul_diploma_school'];
 $qul_diploma_board=$_POST['qul_diploma_board'];
 $qul_diploma_passingyear=$_POST['qul_diploma_passingyear'];
 $qul_diploma_percentage=$_POST['qul_diploma_percentage'];
 $qul_diploma_pcm=$_POST['qul_diploma_pcm'];
 $any_other_qul=$_POST['any_other_qul'];
 $any_other_qul=$_POST['any_other_qul'];*/


  $cast_certificate=$_POST['cast_certificate'];
   $domicile_certificate=$_POST['domicile_certificate'];
    $income_certificate=$_POST['income_certificate'];
	 $transfer_certificate=$_POST['transfer_certificate'];
	  $matric_certificate=$_POST['matric_certificate'];
	   $inter_mark=$_POST['inter_mark'];
	    $matric_mark=$_POST['matric_mark'];
		 @$gradu_certificate=$_POST['gradu_certificate'];





 	$fname1 = $_FILES['student_photo']['name'];
	$student_photo = $_FILES['student_photo']['tmp_name'];
	$f_size1 = $_FILES['student_photo']['size'];

	$f_ext1 = explode('.',$fname1);
	 $f_ext1= strtolower(end($f_ext1));
 $f_newfile1 = uniqid().'.'.$f_ext1;
	$store1 = "photos/".$f_newfile1;

	 if ($f_ext1=='jpg'|| $f_ext1=='png' || $f_ext1=='gif' || $f_ext1=='doc'){

		 echo "";

		 move_uploaded_file($student_photo,$store1);

	}





	$query="insert into main (adm_date,StudentName,date_of_birth,Course,stream,Branch,DOB,AdmThrough,Category,Address,Phone,
	nature_of_admission,email_id,aadhar_number,high_school_roll,add_office,bus_opted,hostel_opted,add_category,cast_cert,domecile_cert,income_cert,transfer_cert,matric_mark,inter_mark,
	matric_cert,graduation,FatherName,MotherName,Occupation,MobileNo,Photo,Session,default_session)

	 values ('$date1','$name','$dob','$course','$stream','$branch','$dob','$admission_through','$stucat','$address1','$mobile_student',
	 '$nature_admission','$email','$aadhaar','$rollno','$admission_office','$bus_opted','$hostel_opted',
	 '$admission_category','$cast_certificate','$domicile_certificate','$income_certificate','$transfer_certificate',
	 '$matric_mark','$inter_mark','$matric_certificate','$gradu_certificate','$father','$mothername','$father_occupation',
	 '$mobile_parents','$student_photo','$year','$year')";
	if (mysql_query($query)){
		$colid=mysql_insert_id();
		$mainid=$colid ;
		$query3="update main set StudentID='$colid' where id_main='$mainid'";
		$run2=mysql_query($query3);

			$query110="select * from main where StudentID='$mainid'";
			$run110=mysql_query($query110);
			while ($row110=mysql_fetch_array($run110)){

			 $main_id110=$row110['id_main'];


			}
			$hello=$main_id110;

			$query112="update main set StudentID='$hello' where student_id='$main_id110'";
			$run112=mysql_query($query112);
			}

				else{
		mysql_error();
	}


echo '<br><table class="table table-bordered">
<tr>
<td colspan=5><img src=logoimg/1.png width=80 height=100><h2 style="margin-top:-100px; margin-left:130px;"></td></td>

</tr>
<tr>
<td width="150">Student Id</td>
<td bgcolor="white"><b>'.$hello.'</b></td></tr></table><br>';


	}
	?>
