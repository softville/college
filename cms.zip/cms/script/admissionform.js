$(document).ready(function(){
  alert('ready');
  $('.name-cls').keyup(function(){
    alert('hi')
    var txt = $(this).val();
    if(txt.match(/^[a-zA-Z]+$/))
    {
      $(this).addClass('has-success');
    }
    else
    {
      $(this).addClass('has-error');
    }
  })
})
