$(document).ready(function()
{
  $(':checkbox').click(function()
  {
    if($(this).is(':checked'))
    {
      $('#passtxt').attr('type','text');
    }
    else if(!$(this).is(':checked'))
    {
      $('#passtxt').attr('type','password');
    }
  });

  $('.arrow').click(function()
  {
           $(".acc-login").slideToggle("slow");
           $(".login").slideToggle("slow");
           $(".fa-arrow-circle-down").css('color','#1079B1');
           $(".fa-arrow-circle-up").css('color','#525659');
           return false;
  });
});
