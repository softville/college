$(document).ready(function(){
	$('.ece,.cs,.en,.ce,.it,.me,.mep,.mea,.bsc_pcm,.bsc_zbc,.bsc_home_science,.ba,.bba,.mba,.pgdm,.bcomh,.bcom,.bed,.btc,.ntt,.others').hide();

	$('.bpm,.bsc1,.bsc2,.bsc3,.mba1,.pgdm1,.ba1,.bba1,.bcom1,.bcomh1,.bed1,.btc1,.ntt1').hide();

$('#sop').change(function(){

	var sop=$(this).find('option:selected').val();

	if (sop=='m-tech' || sop=='b-tech' || sop=='polytechnic'){

		$('.bpm').show();
		$('.bsc1,.bsc2,.bsc3,.mba1,.pgdm1,.ba1,.bba1,.bcom1,.bcomh1,.bed1,.btc1,.ntt1').hide();
	}
	else if (sop=='bsc_pcm'){
		$('.bsc1').show();
		$('.bpm,.bsc2,.bsc3,.mba1,.pgdm1,.ba1,.bba1,.bcom1,.bcomh1,.bed1,.btc1,.ntt1').hide();

	}
	else if (sop=='bsc_zbc'){
		$('.bsc2').show();
		$('.bpm,.bsc1,.bsc3,.mba1,.pgdm1,.ba1,.bba1,.bcom1,.bcomh1,.bed1,.btc1,.ntt1').hide();

	}

	else if (sop=='bsc_home_science'){
		$('.bsc3').show();
		$('.bpm,.bsc1,.bsc2,.mba1,.pgdm1,.ba1,.bba1,.bcom1,.bcomh1,.bed1,.btc1,.ntt1').hide();

	}

	else if (sop=='mba'){
		$('.mba1').show();
		$('.bpm,.bsc1,.bsc2,.bsc3,.pgdm1,.ba1,.bba1,.bcom1,.bcomh1,.bed1,.btc1,.ntt1').hide();

	}

	else if (sop=='pgdm'){
		$('.pgdm1').show();
		$('.bpm,.bsc1,.bsc2,.mba1,.bsc3,.ba1,.bba1,.bcom1,.bcomh1,.bed1,.btc1,.ntt1').hide();

	}

	else if (sop=='ba'){
		$('.ba1').show();
		$('.bpm,.bsc1,.bsc2,.mba1,.pgdm1,.bsc3,.bba1,.bcom1,.bcomh1,.bed1,.btc1,.ntt1').hide();

	}

	else if (sop=='bba'){
		$('.bba1').show();
		$('.bpm,.bsc1,.bsc2,.mba1,.pgdm1,.bsc3,.ba1,.bcom1,.bcomh1,.bed1,.btc1,.ntt1').hide();

	}

	else if (sop=='bcom'){
		$('.bcom1').show();
		$('.bpm,.bsc1,.bsc2,.mba1,.pgdm1,.bsc3,.bba1,.ba1,.bcomh1,.bed1,.btc1,.ntt1').hide();

	}

	else if (sop=='bcomh'){
		$('.bcomh1').show();
		$('.bpm,.bsc1,.bsc2,.mba1,.pgdm1,.bsc3,.bba1,.bcom1,.ba1,.bed1,.btc1,.ntt1').hide();

	}

	else if (sop=='bed'){
		$('.bed1').show();
		$('.bpm,.bsc1,.bsc2,.mba1,.pgdm1,.bsc3,.bba1,.bcom1,.bcomh1,.ba1,.btc1,.ntt1').hide();

	}

	else if (sop=='btc'){
		$('.btc1').show();
		$('.bpm,.bsc1,.bsc2,.mba1,.pgdm1,.bsc3,.bba1,.bcom1,.bcomh1,.bed1,.ba1,.ntt1').hide();

	}
	else if (sop=='ntt'){
		$('.ntt1').show();
		$('.bpm,.bsc1,.bsc2,.mba1,.pgdm1,.bsc3,.bba1,.bcom1,.bcomh1,.bed1,.btc1,.ba1').hide();

	}
	else {

		$('.bpm,.bsc1,.bsc2,.bsc3,.mba1,.pgdm1,.ba1,.bba1,.bcom1,.bcomh1,.bed1,.btc1,.ntt1').hide();

	}
});

$('#stream').change(function(){

	var show=$(this).find('option:selected').val();

	if (show=='Electronics and Communication'){
		$('.ece').show();
		$('.cs,.en,.ce,.it,.me,.mep,.mea,.bsc_pcm,.bsc_zbc,.bsc_home_science,.ba,.bba,.mba,.pgdm,.bcomh,.bcom,.bed,.btc,.ntt,.others').hide();
	}

	else if (show=='Computer Science'){
		$('.cs').show();
		$('.ece,.en,.ce,.it,.me,.mep,.mea,.bsc_pcm,.bsc_zbc,.bsc_home_science,.ba,.bba,.mba,.pgdm,.bcomh,.bcom,.bed,.btc,.ntt,.others').hide();

	}

	else if (show=='Electrical Network'){
		$('.en').show();
		$('.ece,.cs,.ce,.it,.me,.mep,.mea,.bsc_pcm,.bsc_zbc,.bsc_home_science,.ba,.bba,.mba,.pgdm,.bcomh,.bcom,.bed,.btc,.ntt,.others').hide();

	}

	else if (show=='Civil Engineering'){
		$('.ce').show();
		$('.ece,.cs,.en,.it,.me,.mep,.mea,.bsc_pcm,.bsc_zbc,.bsc_home_science,.ba,.bba,.mba,.pgdm,.bcomh,.bcom,.bed,.btc,.ntt,.others').hide();

	}

	else if (show=='Information technology'){
		$('.it').show();
		$('.ece,.cs,.en,.ce,.me,.mep,.mea,.bsc_pcm,.bsc_zbc,.bsc_home_science,.ba,.bba,.mba,.pgdm,.bcomh,.bcom,.bed,.btc,.ntt,.others').hide();

	}

	else if (show=='Mechanical Engineering'){
		$('.me').show();
		$('.ece,.cs,.en,.ce,.it,.mep,.mea,.bsc_pcm,.bsc_zbc,.bsc_home_science,.ba,.bba,.mba,.pgdm,.bcomh,.bcom,.bed,.btc,.ntt,.others').hide();

	}

	else if (show=='Mechanical Engineering Production'){
		$('.mep').show();
		$('.ece,.cs,.en,.ce,.it,.mea,.me,.bsc_pcm,.bsc_zbc,.bsc_home_science,.ba,.bba,.mba,.pgdm,.bcomh,.bcom,.bed,.btc,.ntt,.others').hide();

	}

	else if (show=='Mechanical Engineering Automobile'){
		$('.mea').show();
		$('.ece,.cs,.en,.ce,.it,.mep,.me,.bsc_pcm,.bsc_zbc,.bsc_home_science,.ba,.bba,.mba,.pgdm,.bcomh,.bcom,.bed,.btc,.ntt,.others').hide();

	}

	else if (show=='BSC-PCM'){
		$('.bsc_pcm').show();
		$('.ece,.cs,.en,.ce,.it,.mep,.me,.mea,.bsc_zbc,.bsc_home_science,.ba,.bba,.mba,.pgdm,.bcomh,.bcom,.bed,.btc,.ntt,.others').hide();

	}

	else if (show=='bsc_zbc'){
		$('.bsc_zbc').show();
		$('.ece,.cs,.en,.ce,.it,.mep,.me,.mea,.bsc_pcm,.bsc_home_science,.ba,.bba,.mba,.pgdm,.bcomh,.bcom,.bed,.btc,.ntt,.others').hide();

	}

	else if (show=='bsc_home_science'){
		$('.bsc_home_science').show();
		$('.ece,.cs,.en,.ce,.it,.mep,.me,.mea,.bsc_pcm,.bsc_zbc,.ba,.bba,.mba,.pgdm,.bcomh,.bcom,.bed,.btc,.ntt,.others').hide();

	}

	else if (show=='mba'){
		$('.mba').show();
		$('.ece,.cs,.en,.ce,.it,.mep,.me,.mea,.bsc_pcm,.bsc_zbc,.ba,.bba,.bsc_home_science,.pgdm,.bcomh,.bcom,.bed,.btc,.ntt,.others').hide();

	}

	else if (show=='pgdm'){
		$('.pgdm').show();
		$('.ece,.cs,.en,.ce,.it,.mep,.me,.mea,.bsc_pcm,.bsc_zbc,.ba,.bba,.bsc_home_science,.mba,.bcomh,.bcom,.bed,.btc,.ntt,.others').hide();

	}

	else if (show=='ba'){
		$('.ba').show();
		$('.ece,.cs,.en,.ce,.it,.mep,.me,.mea,.bsc_pcm,.bsc_zbc,.pgdm,.bba,.bsc_home_science,.mba,.bcomh,.bcom,.bed,.btc,.ntt,.others').hide();

	}

	else if (show=='bba'){
		$('.bba').show();
		$('.ece,.cs,.en,.ce,.it,.mep,.me,.mea,.bsc_pcm,.bsc_zbc,.ba,.pgdm,.bsc_home_science,.mba,.bcomh,.bcom,.bed,.btc,.ntt,.others').hide();

	}

	else if (show=='bcom'){
		$('.bcom').show();
		$('.ece,.cs,.en,.ce,.it,.mep,.me,.mea,.bsc_pcm,.bsc_zbc,.ba,.pgdm,.bsc_home_science,.mba,.bcomh,.bba,.bed,.btc,.ntt,.others').hide();

	}

    else if (show=='bcom(h)'){
		$('.bcomh').show();
		$('.ece,.cs,.en,.ce,.it,.mep,.me,.mea,.bsc_pcm,.bsc_zbc,.ba,.pgdm,.bsc_home_science,.mba,.bcom,.bba,.bed,.btc,.ntt,.others').hide();

	}

	else if (show=='b.ed'){
		$('.bed').show();
		$('.ece,.cs,.en,.ce,.it,.mep,.me,.mea,.bsc_pcm,.bsc_zbc,.ba,.pgdm,.bsc_home_science,.mba,.bcom,.bba,.bcomh,.btc,.ntt,.others').hide();

	}

	else if (show=='b.ed'){
		$('.bed').show();
		$('.ece,.cs,.en,.ce,.it,.mep,.me,.mea,.bsc_pcm,.bsc_zbc,.ba,.pgdm,.bsc_home_science,.mba,.bcom,.bba,.bcomh,.btc,.ntt,.others').hide();

	}

	else if (show=='btc'){
		$('.btc').show();
		$('.ece,.cs,.en,.ce,.it,.mep,.me,.mea,.bsc_pcm,.bsc_zbc,.ba,.pgdm,.bsc_home_science,.mba,.bcom,.bba,.bcomh,.bed,.ntt,.others').hide();

	}

	else if (show=='ntt'){
		$('.ntt').show();
		$('.ece,.cs,.en,.ce,.it,.mep,.me,.mea,.bsc_pcm,.bsc_zbc,.ba,.pgdm,.bsc_home_science,.mba,.bcom,.bba,.bcomh,.bed,.btc,.others').hide();

	}

	else {
		$('.ece,.en,.ce,.it,.me,.mep,.mea,.bsc_pcm,.bsc_zbc,.bsc_home_science,.ba,.bba,.mba,.pgdm,.bcomh,.bcom,.bed,.btc,.ntt,.others').hide();

	}
	});

	$('#addcat').change(function(){

	var cat=$(this).find('option:selected').val();

	if (cat=='Lateral Admission'){

		$('#hide1,#hide2,#hide3,#hide4,#hide5,#hide6,#hide7,#hide8').hide();
	}
	else {


	}

	});



	$('#bus').change(function(){

	var sle=$(this).find('option:selected').val();

	if (sle=='Yes'){

		$('.hostel1').hide();
	}
	else {

		$('.hostel1').show();
	}

	});


});
$(function() {
$('#admissiondate').datepicker({});
});
