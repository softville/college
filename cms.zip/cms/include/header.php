<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>College Management System</title>

    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/menu.css" rel="stylesheet">
    <link href="../css/font-awesome-4.6.3/css/font-awesome.min.css" rel="stylesheet" type="text/css">
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
             <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    Menu
                </button>
                <a class="navbar-brand" href="index.html">College Management System</a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right hidden-xs">

                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="../pages/logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>

                </li>

            </ul>

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="../pages/accountstudent.php"><i class="fa fa-dashboard fa-fw"></i>&nbsp;Dashboard</a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-bar-chart-o fa-fw"></i>&nbsp;Master<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li><a href="../pages/department-master.php">Department</a></li>
                                <li><a href="../pages/">Programmes</a></li>
                                <li><a href="../pages/">Degree</a></li>
                                <li><a href="../pages/">Course</a></li>
                                <li><a href="../pages/">Set Active Batch</a></li>
                                <li><a href="../pages/">Subjects</a></li>
                                <li><a href="../pages/">Exam</a></li>
                                <li><a href="../pages/">Unit Master</a></li>
                                <li><a href="../pages/">Model Exam</a></li>
                                <li><a href="../pages/">Admission Type</a></li>
                                <li><a href="../pages/">Class Name</a></li>
                                <li><a href="../pages/">Batch Section</a></li>
                                <li><a href="../pages/">Staff Category</a></li>
                                <li><a href="../pages/">Designations</a></li>
                                <li><a href="../pages/">Communities</a></li>
                                <li><a href="../pages/">Qualifications</a></li>
                                <li><a href="../pages/">Specialization</a></li>
                                <li><a href="../pages/">Cities</a></li>
                                <li><a href="../pages/">States</a></li>
                                <li><a href="../pages/">News Alert</a></li>

                            </ul>

                        </li>
                        <li>
                            <a href="#"><i class="fa fa-bar-chart-o fa-fw"></i>&nbsp;Addmission Cell<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li><a href="../pages/admissionform.php">Enquiry Form</a></li>
                                <li><a href="../pages/addnew.php">New Admission</a></li>
                                <li><a href="../pages/uploadcert.php">Upload Certificate</a></li>
                                <li><a href="../pages/feedetailsearch.php">Submit Fee Detail</a></li>
                                <li><a href="../pages/finedetails.php">Submit Fine Detail</a></li>
                                <li><a href="../pages/documentsubmit.php">Submit Document Detail</a></li>
                                <li><a href="../pages/studentstatus.php">Student Edit/Update</a></li>
                                <li><a href="../pages/studentsession.php">Promote Students</a></li>
                                <li><a href="../pages/exadmission.php">Ex. Admission</a></li>
                                <li><a href="../pages/exfeedetail.php">Submit Fee(Ex. Student)</a></li>
                                <li><a href="../pages/extoreg.php">Convert Ex. to Reg.</a></li>
                            </ul>

                        </li>
                        <li>
                            <a href="#"><i class="fa fa-wrench fa-fw"></i>&nbsp;Accounts<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li><a href="../pages/feereceive.php">Student Fee</a></li>
                                <li><a href="../pages/submitinstall.php">Instaalments</a></li>
                                <li><a href="../pages/studetail.php">Student Details</a>
                                </li>
                            </ul>

                        </li>
                        <li>
                            <a href="#"><i class="fa fa-sitemap fa-fw"></i>&nbsp;Vouchers<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li><a href="../pages/collegeexp.php">College Expense Voucher</a></li>
                                <li><a href="../pages/messexp.php">Mesh Expense Voucher</a></li>
                                <li><a href="../pages/marketingexp.php">Marketing Expense</a></li>
                                <li><a href="../pages/miscexp.php">Misc Expense Voucher</a></li>
                                <li><a href="../pages/receiptvouchers.php">Receipt Voucher</a></li>
                                <li><a href="../pages/finevouchers.php">Fine Voucher</a></li>
                                <li><a href="../pages/advance.php">Advance Voucher</a></li>
                                <li><a href="../pages/oldvouchers.php">Old Data Voucher</a></li>
                            </ul>


                        </li>
                        <li>
                            <a href="#"><i class="fa fa-files-o fa-fw"></i>&nbsp;Records<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li><a href="../pages/viewadmissions.php">Admission Record (Data Wise)</a></li>
                                <li><a href="../pages/stureportyear.php">Admission Record (Year Wise)</a></li>
                                <li><a href="../pages/stureportcat.php">Admission Record (Cat. Wise)</a></li>
                                <li><a href="../pages/returndocument.php">Return Origional Document</a></li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-files-o fa-fw"></i>&nbsp;Report<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li><a href="../pages/dayreport.php">Day Report</a></li>
                                <li><a href="../pages/allheadsreport.php">Fee Report Total</a></li>
                                <li><a href="../pages/stufullstatement.php">Student Fee Statement</a></li>
                                <li><a href="../pages/receivedfeereport.php">Fee Report (Head Wise)</a></li>
                                <li><a href="../pages/feereportcourse.php">Fee Report Course Wise</a>
                                <li><a href="../pages/carryoverreports.php">Carry Over Report</a></li>
                                <li><a href="../pages/pendingamountsession.php">Pending Fee (Session)</a></li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-files-o fa-fw"></i>&nbsp;Voucher Report<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li><a href="../pages/collexpreport.php">College Expense Report</a></li>
                                <li><a href="../pages/messexpreport.php">Mess Expense Report</a></li>
                                <li><a href="../pages/marketingexpreport.php">Marketing Expense Report</a></li>
                                <li><a href="../pages/miscexpreport.php">Misc Expense Report</a></li>
                                <li><a href="../pages/receiptvoucherreport.php">Receipt Voucher Report</a></li>
                                <li><a href="../pages/advancereport.php">Advance Report</a></li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-files-o fa-fw"></i>&nbsp;Admin<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li><a href="#">Admin Login</a></li>
                                <li><a href="../pages/changesession.php">Change Session</a></li>
                                <li><a href="../pages/defaultfee.php">Change Default Fee</a></li>
                                <li><a href="../pages/viewcandidates.php">Enquiry List</a></li>
                                <li><a href="../pages/changestufee.php">Change Regular Student Fee</a></li>
                                <li><a href="../pages/createusers.php">Create User</a></li>
                            </ul>
                            <!--/.nav-second-level-->
                        </li>
                         <li>
                            <a href="index.html."><i class="fa fa-edit fa-fw"></i>&nbsp;Logout</a>
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">

    <script src="../script/jquery.min.js"></script>
    <script src="../script/bootstrap.min.js"></script>
    <script src="../script/metisMenu.min.js"></script>
    <script src="../script/menu.js"></script>
</body>
</html>
