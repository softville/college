<?php
session_start();
//if(!isset($_SESSION['username'])){
?>
<?php
include('../include/header.php');
//include('../functions/function.php');
?>

<!DOCTYPE html>

<head>
  <meta charset="utf-8">
  <title>Rajshree Admission Form</title>
  <link rel="stylesheet" href="../css/ui-lightness/jquery-ui-1.10.4.custom.css">
  <script src="../script/addnew.js"></script>
  <script type="text/javascript" src="../script/jquery-ui-1.10.4.custom.js"></script>

  <script src="./script/bootstrap.min.js"></script>
  <script type="text/javascript" src="./script/jquery.min.js"></script>
</head>
<body>
       <br><br>
       <div class="panel panel-primary">
           <div class="panel-heading">
               <h1 class="panel-title">Add New Department</h1>
           </div>
       </div>
       <!-- /.row -->
       <div class="row">
           <div class="col-lg-12">
               <div class="panel panel-info">
                   <div class="panel-heading">
                       Fill Details
                   </div>
                   <div class="panel-body">
                       <div class="row">
                           <div class="col-lg-12">
                               <form role="form" class="form-horizontal" action='' method='post' enctype="multipart/form-data">
                                   <div class="row">
                                       <div class="col-md-12">
                                           <div class="form-group">
                                               <label class="control-label col-md-3 text-left" for="name">Department Name:</label>
                                               <div class="col-md-6">
                                                   <input type="text" name="dept-name" class="form-control name-cls" placeholder="Enter Department Name" autocomplete="off" required autofocus />
                                               </div>
                                           </div>
                                       </div>
                                   </div>
                                   <div class="row">
																			<div class="col-md-12 text-center">
																					<div class="form-group">
																							<input type='submit' class="btn btn-primary" name='submit_general' value='Submit'>
 																					</div>
 																				</div>
 																		</div>
                               </form>
                           </div>
                       </div>
                   </div>
                </div>
           </div>
       </div>
       <div class="row">
           <div class="col-lg-12">
               <div class="panel panel-info">
                   <div class="panel-heading">
                       Existing List Of Department
                   </div>
                   <div class="panel-body">
                       <div class="row">
                           <div class="col-lg-12">
                               <form role="form" class="form-horizontal" action='' method='post' enctype="multipart/form-data">
                                   <div class="row">
                                       <div class="col-md-12 table-responsive">
                                         <table class="table table-default table-bordered">
                                           <thead class="thead-default">
                                             <tr class="row text-center">
                                               <th colspan="2" class="text-info">Added Department
                                               </th>
                                             </tr>
                                           </thead>
                                           <tr class="row col-name text-center">
                                             <td>
                                               Delete
                                             </td>
                                             <td>
                                               Department Name
                                             </td>
                                           </tr>

                                           <tr class="row text-center">
                                             <td>
                                               <a href=""><i class="fa fa-trash-o text-danger fa-2x" aria-hidden="true"></i></span></a>
                                             </td>
                                             <td>Deptt. name
                                             </td>
                                           </tr>
                                         </table>
                                      </div>
                                   </div>
                               </form>
                           </div>
                       </div>
                       <div class="row">
                           <div class="col-lg-12">
                               <form role="form" class="form-horizontal" action='' method='post' enctype="multipart/form-data">
                                   <div class="row">
                                       <div class="col-md-12 table-responsive">
                                         <table class="table table-default table-bordered">
                                           <thead class="thead-default">
                                             <tr class="row text-center">
                                               <th colspan="2" class="text-info">Deleted Department
                                               </th>
                                             </tr>
                                           </thead>
                                           <tr class="row col-name text-center">
                                             <td>
                                               Activate
                                             </td>
                                             <td>
                                               Department Name
                                             </td>
                                           </tr>

                                           <tr class="row text-center">
                                             <td>
                                               <a href=""><i class="fa fa-undo text-danger fa-2x" aria-hidden="true"></i></span></a>
                                             </td>
                                             <td>Deptt. name
                                             </td>
                                           </tr>
                                         </table>
                                      </div>
                                   </div>
                               </form>
                           </div>
                       </div>
                   </div>
                </div>
           </div>
       </div>
   </body>

	 </html>

	 <?php
	 include('../include/footer.php');
	 ?>
