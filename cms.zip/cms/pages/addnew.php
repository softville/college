<?php
session_start();
//if(!isset($_SESSION['username'])){


	?>

<?php
include('../include/header.php');
include('../functions/function.php');
?>


<!DOCTYPE html>

<head>
<meta charset="utf-8">
<title>Rajshree Admission Form</title>
<link rel="stylesheet" href="../css/ui-lightness/jquery-ui-1.10.4.custom.css">
<script src="../script/addnew.js"></script>
<script type="text/javascript" src="../script/jquery-ui-1.10.4.custom.js"></script>

<script src="./script/bootstrap.min.js"></script>
<script type="text/javascript" src="./script/jquery.min.js"></script>
</head>


<?php
 date("y-d-m");
$queryse="select * from session where id=1";
$runs=mysql_query($queryse);
while($rowse=mysql_fetch_array($runs)){

	$session=$rowse['surrent_session'];
}

?>

<body>
       <br><br>
       <div class="panel panel-primary">
           <div class="panel-heading">
               <h1 class="panel-title">New Admission</h1>
           </div>
       </div>
       <!-- /.row -->
       <div class="row">
           <div class="col-lg-12">
               <div class="panel panel-info">
                   <div class="panel-heading">
                       Fill Details
                   </div>
                   <div class="panel-body">
                       <div class="row">
                           <div class="col-lg-12">
                               <form role="form" class="form-horizontal" action='showadmissiondetail.php?session=<?php echo $session; ?>' method='post' enctype="multipart/form-data">
                                   <div class="row">
                                       <div class="col-md-6">
                                           <div class="form-group">
                                               <label class="control-label col-md-4 text-left" for="name">Student's Name:</label>
                                               <div class="col-md-8">
                                                   <input type="text" name="name" class="form-control name-cls" placeholder="Enter Student's Name" autocomplete="off" required autofocus />
                                               </div>
                                           </div>
                                       </div>
                                       <div class="col-md-6">
                                           <div class="form-group">
                                              <label class="control-label col-md-4" for="lname">Session:</label>
                                               <div class="col-md-8">
                                                   <input type="text" name='year' value='<?php echo $session; ?>' disabled class="form-control"/>
                                               </div>
                                           </div>
                                       </div>
                                   </div>
                                   <div class="row">
                                       <div class="col-md-6">
                                           <div class="form-group">
                                               <label class="col-md-4 control-label" for="fname">Father's Name:</label>
                                               <div class="col-md-8">
                                                   <input type="text" name="father" placeholder="Enter Father's Name" autocomplete="off" class="form-control name-cls" required />
                                               </div>
                                           </div>
                                       </div>
                                       <div class="col-md-6">
                                           <div class="form-group">
                                               <label class="col-md-4 control-label" for="occupation">Course:</label>
                                               <div class="col-md-8">
																								 <select name="course" class="form-control" id='sop' required>

																											 <option selected='selected' value='pleaseselect'>Please Select</option>
																											 <option value='m-tech'>M-tech</option>
																											 <option value='b-tech'>B-tech</option>
																											 <option value='polytechnic'>Polytechnic</option>
																											 <option value='bsc_pcm'>BSC-PCM</option>
																								<option value='bsc_zbc'>BSC-ZBC</option>
																								<option value='bsc_home_science'>BSC Home Science</option>
																								<option value='mba'>MBA</option>
																											 <option value='pgdm'>PGDM</option>
																											 <option value='ba'>BA</option>
																											 <option value='bba'>BBA</option>
																								<option value='bcom'>BCOM</option>
																											 <option value='bcom_h'>BCOM(H)</option>
																											 <option value='bed'>B.ED</option>
																											 <option value='btc'>BTC</option>
																								<option value='ntt'>NTT</option>
																											 <option value='others'>OTHERS</option>
																										 </select>
                                               </div>
                                           </div>
                                       </div>
                                   </div>
																	 <div class="row">
																			 <div class="col-md-6">
																					 <div class="form-group">
																							 <label class="col-md-4 control-label" for="fname">Mother's Name:</label>
																							 <div class="col-md-8">
																									 <input type="text" id='show' name="mothername" placeholder="Enter Mother's Name" autocomplete="off" class="form-control name-cls" required />
																							 </div>
																					 </div>
																			 </div>
																			 <div class="col-md-6">
																					 <div class="form-group">
																							 <label class="col-md-4 control-label" for="occupation">Stream:</label>
																							 <div class="col-md-8">
																								 <select id='stream' name="stream" class="form-control" required>
 																					             <option selected='selected' value='pleaseselect'>Please Select</option>
 																					             <option class="bpm" value='Electronics and Communication'>Electronics and Communication</option>
 																					 				 		 <option class="bpm" value='Computer Science'>Computer Science</option>
 																					 						 <option class="bpm" value='Electrical Network'>Electrical Network</option>
 																					 						 <option class="bpm" value='Civil Engineering'>Civil Engineering</option>
 																					 						 <option class="bpm" value='Information technology'>Information technology</option>
 																					 						 <option class="bpm" value='Mechanical Engineering'>Mechanical Engineering</option>
 																					 						 <option class="bpm" value='Mechanical Engineering Production'>Mechanical Engineering Production</option>
 																					 						 <option class="bpm" value='Mechanical Engineering Automobile'>Mechanical Engineering Automobile</option>
 																					 						 <option class="bsc1" value='BSC-PCM'>BSC-PCM</option>
 																					 						 <option class="bsc2" value='bsc_zbc'>BSC-ZBC</option>
 																					 						 <option class="bsc3" value='bsc_home_science'>BSC Home Science</option>
 																					 						 <option class="mba1" value='mba'>MBA</option>
 																					 						 <option class="pgdm1" value='pgdm'>PGDM</option>
 																					 						 <option class="ba1" value='ba'>BA</option>
 																					 						 <option class="bba1" value='bba'>BBA</option>
 																					 						 <option class="bcom1" value='bcom'>BCOM</option>
 																					 						 <option class="bcomh1" value='bcom(h)'>BCOM(H)</option>
 																					 						 <option class="bed1" value='b.ed'>B.ED</option>
 																					 						 <option class="btc1" value='btc'>BTC</option>
 																					 						 <option class="ntt1" value='ntt'>NTT</option>
 																					        </select>
																							</div>
																					 </div>
																			 </div>
																	 </div>
																	 <div class="row">
                                       <div class="col-md-6">
                                           <div class="form-group">
                                               <label class="control-label col-md-4 text-left" for="name">Contact (Student):</label>
                                               <div class="col-md-8">
                                                   <input type="text" name="mobile_student" class="form-control num-only" placeholder='Enter Mobile No.'autocomplete="off" />
                                               </div>
                                           </div>
                                       </div>
                                       <div class="col-md-6">
                                           <div class="form-group">
                                              <label class="control-label col-md-4" for="lname">Admission&nbsp;Category:</label>
                                               <div class="col-md-8">
																								<select id='addcat' class="form-control" name="admission_category" required>
																								 	<option value='please select'>Please Select</option>
																								 	<option value='New Admission'>New Admission</option>
																									<option value='Lateral Admission'>Lateral Admission</option>
																								</select>
                                               </div>
                                           </div>
                                       </div>
                                   </div>
																	 <div class="row">
                                       <div class="col-md-6">
                                           <div class="form-group">
                                               <label class="control-label col-md-4 text-left" for="name">Contact (Parents):</label>
                                               <div class="col-md-8">
                                                   <input type="text" name="mobile_parents" class="form-control num-only" placeholder="Enter Parent's Mobile No." autocomplete="off" required/>
                                               </div>
                                           </div>
                                       </div>
                                       <div class="col-md-6">
                                           <div class="form-group">
                                              <label class="control-label col-md-4" for="lname">Branch:</label>
                                               <div class="col-md-8">
																								 <select id='display1' class="form-control" name="branch" required>
 																						  <div id='display11'>
 																					      <option value='pleaseselect'>Please Select</option>
 																					      <option id='hide1' class="ece" id='laterl' value='EC-I'>EC-I</option>
 																								<option class="ece" value='EC-II'>EC-II</option>
 																								<option class="ece" value='EC-III'>EC-III</option>
 																								<option class="ece" value='EC-IV'>EC-IV</option>
 																								<option id='hide2' class="cs" id='laterl' value='CS-I'>CS-I</option>
 																								<option class="cs" value='CS-II'>CS-II</option>
 																								<option class="cs" value='CS-III'>CS-III</option>
 																								<option class="cs" value='CS-IV'>CS-IV</option>
 																								<option id='hide3' class="en" id='en1' value='EN-I'>EN-I</option>
 																								<option class="en" value='EN-II'>EN-II</option>
 																								<option class="en" value='EN-III'>EN-III</option>
 																								<option class="en" value='EN-IV'>EN-IV</option>
 																								<option id='hide4' class="ce" id='ce1' value='CE-I'>CE-I</option>
 																								<option class="ce" value='CE-II'>CE-II</option>
 																								<option class="ce" value='CE-III'>CE-III</option>
 																								<option class="ce" value='CE-IV'>CE-IV</option>
 																								<option id='hide5' class="it" id='it1' value='IT-I'>IT-I</option>
 																								<option class="it" value='IT-II'>IT-II</option>
 																								<option class="it" value='IT-III'>IT-III</option>
 																								<option class="it" value='IT-IV'>IT-IV</option>
 																								<option id='hide6' class="me" id='me1' value='ME-I'>ME-I</option>
 																								<option class="me" value='ME-II'>ME-II</option>
 																								<option class="me" value='ME-III'>ME-III</option>
 																								<option class="me" value='ME-IV'>ME-IV</option>
 																								<option id='hide7' class="mep" id='mep1' value='MEP-I'>MEP-I</option>
 																								<option class="mep" value='MEP-II'>MEP-II</option>
 																								<option class="mep" value='MEP-III'>MEP-III</option>
 																								<option id='hide8' class="mea" id='mea1' value='MEA-I'>MEA-I</option>
 																								<option class="mea" value='MEA-II'>MEA-II</option>
 																								<option class="mea" value='MEA-III'>MEA-III</option>
 																								<option class="bsc_pcm" value='bsc_pcm-I'>BSC-PCM-I</option>
 																								<option class="bsc_pcm" value='bsc_pcm-II'>BSC-PCM-II</option>
 																								<option class="bsc_pcm" value='bsc_pcm-III'>BSC-PCM-III</option>
 																								<option class="bsc_zbc" value='bsc_zbc-I'>BSC-ZBC-I</option>
 																								<option class="bsc_zbc" value='bsc_zbc-II'>BSC-ZBC-II</option>
 																								<option class="bsc_zbc" value='bsc_zbc-III'>BSC-ZBC-III</option>
 																								<option class="bsc_home_science" value='bsc_home_science-I'>BSC Home Science-I</option>
 																								<option class="bsc_home_science" value='bsc_home_science-II'>BSC Home Science-II</option>
 																								<option class="bsc_home_science" value='bsc_home_science-III'>BSC Home Science-III</option>
 																								<option class="mba" value='mba-I'>MBA-I</option>
 																								<option class="mba" value='mba-II'>MBA-II</option>
 																					      <option class="pgdm" value='pgdm-I'>PGDM-I</option>
 																								<option class="pgdm" value='pgdm-II'>PGDM-II</option>
 																					      <option class="ba" value='ba-I'>BA-I</option>
 																								<option class="ba" value='ba-II'>BA-II</option>
 																								<option class="ba" value='ba-III'>BA-III</option>
 																					      <option class="bba" value='bba-I'>BBA-I</option>
 																								<option class="bba" value='bba-II'>BBA-II</option>
 																								<option class="bba" value='bba-III'>BBA-III</option>
 																								<option class="bcom" value='bcom-I'>BCOM-I</option>
 																								<option class="bcom" value='bcom-II'>BCOM-II</option>
 																								<option class="bcom" value='bcom-III'>BCOM-III</option>
 																					      <option class="bcomh" value='bcom(h)-I'>BCOM(H)-I</option>
 																								<option class="bcomh" value='bcom(h)-II'>BCOM(H)-II</option>
 																								<option class="bcomh" value='bcom(h)-III'>BCOM(H)-III</option>
 																					      <option class="bed" value='b.ed-I'>B.ED-I</option>
 																								<option class="bed" value='b.ed-II'>B.ED-II</option>
 																					      <option class="btc" value='btc-I'>BTC-I</option>
 																								<option class="btc" value='btc-II'>BTC-II</option>
 																								<option class="ntt" value='ntt'>NTT</option>
																							</div>
 																					  </select>
                                          </div>
                                         </div>
                                       </div>
                                   </div>
																	 <div class="row">
																				<div class="col-md-6">
																						<div class="form-group">
																								<label class="control-label col-md-4 text-left" for="name">E-mail Id:</label>
																								<div class="col-md-8">
																										<input type="email" name="email" class="form-control" placeholder="Enter Email Id" autocomplete="off" required/>
																								</div>
																						</div>
																				</div>
																				<div class="col-md-6">
																						<div class="form-group">
																							 <label class="control-label col-md-4" for="lname">Nature&nbsp;Of&nbsp;Admission:</label>
																								<div class="col-md-8">
																									<select class="form-control" name="nature_admission" required>
																										<option selected="selected" value='pleaseselect'>Please Select</option>
																										<option value='scholarship'>Scholarship</option>
																										<option value='high_income'>High Income</option>
																										<!--<option value='50-50_scholarship'>50-50 Scholarship</option>-->
																									</select>
																					 			</div>
																						</div>
																				</div>
																		</div>
																		<div class="row">
 																				<div class="col-md-6">
 																						<div class="form-group">
 																								<label class="control-label col-md-4 text-left">Date&nbsp;of&nbsp;Admission:</label>
 																								<div class="col-md-8">
 																										<input type="text" id="admissiondate" name="admission_date" class="form-control" placeholder="Click Here to Select Date" autocomplete="off" readonly/>
 																								</div>
 																						</div>
 																				</div>
 																				<div class="col-md-6">
 																						<div class="form-group">
 																							 <label class="control-label col-md-4" for="lname">Domicile&nbsp;Certificate:</label>
 																								<div class="col-md-8">
																									<select class="form-control" name="domicile_certificate" required>
																								  	<option value='original'>Original</option>
																								  	<option value='xerox'>Xerox</option>
																								  	<option value='Both'>Both</option>
																								  	<option value='None'>None</option>
																								  </select>
 																					 			</div>
 																						</div>
 																				</div>
 																		</div>
																		<div class="row">
 																				<div class="col-md-6">
 																						<div class="form-group">
 																								<label class="control-label col-md-4 text-left">Date&nbsp;of&nbsp;Birth:</label>
 																								<div class="col-md-8">
 																										<input type="text" name="dob" class="form-control" placeholder='DD/MM/YYYY' autocomplete="off" required/>
 																								</div>
 																						</div>
 																				</div>
 																				<div class="col-md-6">
 																						<div class="form-group">
 																							 <label class="control-label col-md-4" for="lname">Income&nbsp;Certificate:</label>
 																								<div class="col-md-8">
																									<select class="form-control" name="income_certificate" required>
																										<option value='original'>Original</option>
																										<option value='xerox'>Xerox</option>
																										<option value='Both'>Both</option>
																										<option value='None'>None</option>
																									</select>
 																					 			</div>
 																						</div>
 																				</div>
 																		</div>
																		<div class="row">
 																				<div class="col-md-6">
 																						<div class="form-group">
 																								<label class="control-label col-md-4 text-left">Aadhaar Number:</label>
 																								<div class="col-md-8">
 																										<input type="text" name='aadhaar' class="form-control" placeholder='Enter Aadhaar No.' autocomplete="off"/>
 																								</div>
 																						</div>
 																				</div>
 																				<div class="col-md-6">
 																						<div class="form-group">
 																							 <label class="control-label col-md-4" for="">Transfer&nbsp;Certificate:</label>
 																								<div class="col-md-8">
																									<select class="form-control" name="transfer_certificate" required>
																						  			<option value='original'>Original</option>
																						  			<option value='xerox'>Xerox</option>
																						  			<option value='Both'>Both</option>
																						  			<option value='None'>None</option>
																						  		</select>
 																					 			</div>
 																						</div>
 																				</div>
 																		</div>
																		<div class="row">
 																				<div class="col-md-6">
 																						<div class="form-group">
 																								<label class="control-label col-md-4 text-left">10<sup>th</sup> Roll No:</label>
 																								<div class="col-md-8">
 																										<input type="text" name='rollno' class="form-control" placeholder="Enter High School's Roll No." autocomplete="off" required/>
 																								</div>
 																						</div>
 																				</div>
 																				<div class="col-md-6">
 																						<div class="form-group">
 																							 <label class="control-label col-md-4" for="">Matric&nbsp;Certificate:</label>
 																								<div class="col-md-8">
																									<select class="form-control" name="matric_certificate" required>
																								  	<option value='original'>Original</option>
																								  	<option value='xerox'>Xerox</option>
																								  	<option value='Both'>Both</option>
																								  	<option value='None'>None</option>
																								  </select>
 																					 			</div>
 																						</div>
 																				</div>
 																		</div>
																		<div class="row">
																			<div class="col-md-6">
																					<div class="form-group">
																						 <label class="control-label col-md-4" for="">Matric&nbsp;Marksheet:</label>
																							<div class="col-md-8">
																								<select class="form-control" name="matric_mark" required>
																									<option value='original'>Original</option>
																									<option value='xerox'>Xerox</option>
																									<option value='Both'>Both</option>
																									<option value='None'>None</option>
																								</select>
																							</div>
																					</div>
																			</div>
 																				<div class="col-md-6">
 																						<div class="form-group">
 																								<label class="control-label col-md-4 text-left">12<sup>th</sup> Marksheet:</label>
 																								<div class="col-md-8">
																									<select class="form-control" name="inter_mark" required>
																										<option value='original'>Original</option>
																										<option value='xerox'>Xerox</option>
																										<option value='Both'>Both</option>
																										<option value='None'>None</option>
																									</select>
 																								</div>
 																						</div>
 																				</div>
 																		</div>
																		<div class="row">
																			<div class="col-md-6">
																					<div class="form-group">
																						 <label class="control-label col-md-4" for="">Graduation&nbsp;Marksheet:</label>
																							<div class="col-md-8">
																								<select class="form-control" name="gradu_certificate" required>
																									<option value='original'>Original</option>
																									<option value='xerox'>Xerox</option>
																									<option value='Both'>Both</option>
																									<option value='None'>None</option>
																								</select>
																							</div>
																					</div>
																			</div>
 																				<div class="col-md-6">
 																						<div class="form-group">
 																								<label class="control-label col-md-4 text-left">Caste Marksheet:</label>
 																								<div class="col-md-8">
																									<select class="form-control" name="cast_certificate" required>
																										<option value='original'>Original</option>
																										<option value='xerox'>Xerox</option>
																										<option value='Both'>Both</option>
																										<option value='None'>None</option>
																									</select>
 																								</div>
 																						</div>
 																				</div>
 																		</div>
																		<div class="row">
 																				<div class="col-md-6">
 																						<div class="form-group">
 																								<label class="control-label col-md-4 text-left">Father's&nbsp;Occupation:</label>
 																								<div class="col-md-8">
 																										<input type="text" name="father_occupation" class="form-control" placeholder="Enter Father's Occupation" autocomplete="off" required/>
 																								</div>
 																						</div>
 																				</div>
 																				<div class="col-md-6">
 																						<div class="form-group">
 																							 <label class="control-label col-md-4" for="">Admission Office:</label>
 																								<div class="col-md-8">
																									<select name="admission_office" class="form-control" required>
																										<option selected="selected">Office One</option>
																										<option>Office Two</option>
																										<option>Office Three</option>
																										<option>Office Four</option>
																										<option>Office Five</option>
																										<option>Office Six</option>
																										<option>Office Seven</option>
																									</select>
 																					 			</div>
 																						</div>
 																				</div>
 																		</div>
																		<div class="row">
 																				<div class="col-md-6">
 																						<div class="form-group">
 																								<label class="control-label col-md-4 text-left">Address:</label>
 																								<div class="col-md-8">
 																										<textarea name="address1" class="form-control" rows="2" cols="41" placeholder='Enter full Address' required></textarea>
 																								</div>
 																						</div>
 																				</div>
 																				<div class="col-md-6">
 																						<div class="form-group">
 																							 <label class="control-label col-md-4" for="">Admission&nbsp;Through:</label>
 																								<div class="col-md-8">
																									<div class="row">
																										<div class="col-sm-12 text-center">
																											<input type="checkbox" name="admission_through" value="apj_uni" />
																					        		APJ UNI
																					        		<input type="checkbox" name="admission_through" value="management" />
																					        		Management
																					        		<input type="checkbox" name="admission_through" value="BTE" /> BTE
																										</div>
																									</div>
																									<div class="row text-center">
																										<div class="col-sm-12 text-center">

																					        	<input type="checkbox" name="admission_through" value="Direct" />
																					        	Direct
																					        	<input type="checkbox" name="admission_through" value="Other" />
																					        	Other
																									</div>
																								</div>
 																					 			</div>
 																						</div>
 																				</div>
 																		</div>
																		<div class="row">
																			<div class="col-md-6">
																					<div class="form-group">
																						 <label class="control-label col-md-4" for="">Bus Opted:</label>
																							<div class="col-md-8">
																								<select name="bus_opted" class="form-control" id="bus">
																			           <option selected="selected">Please Select</option>
																			           <option value="Yes">Yes</option>
																			           <option value="No">No</option>
																			          </select>
																							</div>
																					</div>
																			</div>
 																				<div class="col-md-6">
 																						<div class="form-group">
 																								<label class="control-label col-md-4 text-left">Hostel Opted:</label>
 																								<div class="col-md-8">
																									<select class="form-control" name="hostel_opted" required>
																										<option class="hostel1" value="Yes">Yes</option>
																					          <option class="hostel1" value="No">No</option>
																									</select>
 																								</div>
 																						</div>
 																				</div>
 																		</div>
																		<div class="row">
																			<div class="col-md-6">
																					<div class="form-group">
																						 <label class="control-label col-md-4" for="">Student Category:</label>
																							<div class="col-md-8">
																								<select name='stucat' class="form-control">
																									<option value='GEN'>Gen</option>
 																							 		<option value='OBC'>OBC</option>
 																							 		<option value='MINORITY'>Minority</option>
 																							 		<option value='SC/ST'>SC/ST</option>
																			          </select>
																							</div>
																					</div>
																			</div>
 																				<div class="col-md-6">
 																						<div class="form-group">
 																								<label class="control-label col-md-4 text-left">Upload Photo:</label>
 																								<div class="col-md-8">
																									<input type="file" name="student_photo" class=""/>
 																								</div>
 																						</div>
 																				</div>
 																		</div>
																		<div class="row">
																			<div class="col-md-12 text-center">
																					<div class="form-group">
																							<input type='submit' class="btn btn-primary" name='submit_general' value='Submit admission form'>
 																					</div>
 																				</div>
 																		</div>
                               </form>
                           </div>
                       </div>
                   </div>
                </div>
           </div>
       </div>
   </body>

	 </html>

	 <?php
	 include('../include/footer.php');
	 ?>
