
<?php

include('../include/header.php');
include('../functions/function.php');
include('../functions/feefunction.php');

?>

<html>
<link rel="stylesheet" href="css/ui-lightness/jquery-ui-1.10.4.custom.css">
<link rel="stylesheet" type="text/CSS" href="style.css">
<script type="text/javascript" src="js/jquery-1.10.2.js"></script>
<script type="text/javascript" src="../script/jquery-ui-1.10.4.custom.js"></script>
<div class="panel panel-primary">
                            <div class="panel-heading">
                                <h3 class="panel-title">Admission Detail of Student</h3>
                            </div>

                        </div>
<?php
if(isset($_POST['submit_general'])){

	 $year_main= $_GET['session'];

	submit_general();

 	$year_main= $_GET['session'];
 $name=$_POST['name'];
 $year1=$year_main;
 $course=$_POST['course'];
 $father=$_POST['father'];
 $branch=$_POST['branch'];
 $mothername=$_POST['mothername'];
 $mobile_student=$_POST['mobile_student'];
 @$student_photo=$_POST['student_photo'];
 $mobile_parents=$_POST['mobile_parents'];
 $nature_admission=$_POST['nature_admission'];
 $address1=$_POST['address1'];
 $email=$_POST['email'];
 $admission_date=$_POST['admission_date'];
 @$date=$_POST['date'];
 $dob=$_POST['dob'];
	$cast_certificate=$_POST['cast_certificate'];
   $domicile_certificate=$_POST['domicile_certificate'];
    $income_certificate=$_POST['income_certificate'];
	 $transfer_certificate=$_POST['transfer_certificate'];
	  $matric_certificate=$_POST['matric_certificate'];
	   $inter_mark=$_POST['inter_mark'];
	    $matric_mark=$_POST['matric_mark'];
		 @$gradu_certificate=$_POST['gradu_certificate'];
}

?>

<script>
function printpage(){

	window.print()
	}

</script>
<html>
<head>
<title>Admission detail</title>
<style type="text/css">

@page{
        size: auto A4 landscape;
        margin: 3mm;
     }

</style>
</head>

<table class="table table-bordered" style="margin-top:-30px;">



<tr class="success"><td colspan="4"><div align="center"><b>Student Detail</b></td></tr>
<tr>


<td>Name of Student</td>
<td><?php echo $name ; ?></td>
</tr>

<td>Father's Name</td>
<td><?php echo $father ; ?></td>
</tr>
<tr>
<td>Year</td>
<td><?php echo $year1 ;?></td>
</tr>
<tr>
<tr>
<td>Course Name</td>
<td><?php echo $course; ?></td>
</tr>
<tr>
<td>Branch</td>
<td><?php echo $branch ;?></td>
</tr>
<tr>
<td>Mobile Number</td>
<td><?php echo $mobile_student ; ?></td>
</tr>
<tr>
<td>Nature of Admission</td>
<td><?php echo $nature_admission ; ?></td>
</tr>
<tr>
<td>Email Id</td>
<td><?php echo $email ; ?></td>
</tr>
<tr>
<td>Admission Date</td>
<td><?php echo $admission_date ; ?></td>
</tr>
<tr>
<td>Date Of Birth</td>
<td><?php echo $dob ; ?></td>
</tr>
<tr>


<tr>
<td align='center' colspan='5'><input type='submit' class="btn btn-primary" name='print' id='printpagebutton' value='Print' onclick='print()'>
<a href='alladmission.php'><input type='submit' class="btn btn-success" name='gohome' value='Home'></a></td>
</tr>
</table>
<script type="text/javascript">
    function printpage() {
        //Get the print button and put it into a variable
        var printButton = document.getElementById("printpagebutton");
		var menu = document.getElementById("menu");
        //Set the print button visibility to 'hidden'
        printButton.style.visibility = 'hidden';
		  menu.style.visibility = 'hidden';
        //Print the page content
        window.print()
        //Set the print button to 'visible' again
        //[Delete this line if you want it to stay hidden after printing]
        printButton.style.visibility = 'visible';
    }
</script>

</html>
<?php include('../include/footer.php'); ?>
