<?php
session_start();
if(!isset($_SESSION['user'])){

header("location:accountlogin.php");
}
else {
	?>
<?php
include('../include/header.php');

include_once('../database/dbconnect.php');
?>
<html>

<head>
	<link rel="stylesheet" href="./css/bootstrap.min.css"/>
  <link rel="stylesheet" href="./css/font-awesome-4.6.3/css/font-awesome.min.css">



  <script src="./script/bootstrap.min.js"></script>
  <script type="text/javascript" src="./script/jquery.min.js"></script>




</head>
<body>
	<div class="panel panel-info">
	  <div class="panel-heading">
			<div class="row">
					<div class="col-lg-12">
						Dashboard
					</div>
					<!-- /.col-lg-12 -->
			</div>
		</div>
		<div class="panel-body">
			<!-- /.row -->
			<div class="row">
					<div class="col-lg-3 col-md-6">
							<div class="panel panel-primary">
									<div class="panel-heading">
											<div class="row">
													<!-- <div class="col-xs-2">
															<i class="fa fa-comments fa-2x"></i>
													</div> -->
													<div class="col-xs-12 text-center">
															<div class="">Student Fee</div>
													</div>
											</div>
									</div>
									<a href="../pages/feereceive.php">
											<div class="panel-footer">
													<span class="pull-left">Click Here</span>
													<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
													<div class="clearfix"></div>
											</div>
									</a>
							</div>
					</div>
					<div class="col-lg-3 col-md-6">
							<div class="panel panel-primary">
									<div class="panel-heading">
											<div class="row">
													<!-- <div class="col-xs-2">
															<i class="fa fa-tasks fa-2x"></i>
													</div> -->
													<div class="col-xs-12 text-center">
															<div class="">Payment&nbsp;Vouchers</div>
													</div>
											</div>
									</div>
									<a href="../pages/vouchers.php">
											<div class="panel-footer">
													<span class="pull-left">Click Here</span>
													<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
													<div class="clearfix"></div>
											</div>
									</a>
							</div>
					</div>
					<div class="col-lg-3 col-md-6">
							<div class="panel panel-primary">
									<div class="panel-heading">
											<div class="row">
													<!-- <div class="col-xs-2">
															<i class="fa fa-shopping-cart fa-2x"></i>
													</div> -->
													<div class="col-xs-12 text-center">
															<div class="">Receipt&nbsp;Vouchers</div>
													</div>
											</div>
									</div>
									<a href="../pages/receiptvouchers.php">
											<div class="panel-footer">
													<span class="pull-left">Click Here</span>
													<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
													<div class="clearfix"></div>
											</div>
									</a>
							</div>
					</div>
					<div class="col-lg-3 col-md-6">
							<div class="panel panel-primary">
									<div class="panel-heading">
											<div class="row">
													<!-- <div class="col-xs-2">
															<i class="fa fa-support fa-2x"></i>
													</div> -->
													<div class="col-xs-12 text-center">
															<div class="">Fine Vouchers</div>
													</div>
											</div>
									</div>
									<a href="../pages/finevouchers.php">
											<div class="panel-footer">
													<span class="pull-left">Click Here</span>
													<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
													<div class="clearfix"></div>
											</div>
									</a>
							</div>
					</div>
					<div class="col-lg-3 col-md-6">
						<div class="panel panel-primary">
									<div class="panel-heading">
											<div class="row">
													<!-- <div class="col-xs-2">
															<i class="fa fa-support fa-2x"></i>
													</div> -->
													<div class="col-xs-12 text-center">
															<div class="">Advance</div>
													</div>
											</div>
									</div>
									<a href="../pages/advance.php">
											<div class="panel-footer">
													<span class="pull-left">Click Here</span>
													<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
													<div class="clearfix"></div>
											</div>
									</a>
							</div>
					</div>
					<div class="col-lg-3 col-md-6">
						<div class="panel panel-primary">
									<div class="panel-heading">
											<div class="row">
													<!-- <div class="col-xs-2">
															<i class="fa fa-support fa-2x"></i>
													</div> -->
													<div class="col-xs-12 text-center">
															<div class="">Carry Over</div>
													</div>
											</div>
									</div>
									<a href="../pages/carryover.php">
											<div class="panel-footer">
													<span class="pull-left">Click Here</span>
													<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
													<div class="clearfix"></div>
											</div>
									</a>
							</div>
					</div>
					<div class="col-lg-3 col-md-6">
						<div class="panel panel-primary">
									<div class="panel-heading">
											<div class="row">
													<!-- <div class="col-xs-2">
															<i class="fa fa-support fa-2x"></i>
													</div> -->
													<div class="col-xs-12 text-center">
															<div class="">Cheque Clearance</div>
													</div>
											</div>
									</div>
									<a href="../pages/chequeclear.php">
											<div class="panel-footer">
													<span class="pull-left">Click Here</span>
													<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
													<div class="clearfix"></div>
											</div>
									</a>
							</div>
					</div>

			</div>
</div>
</div>



<!-- <div id='accounts'>
<table border='2px' bordercolor='black' bgcolor='lightgray' width='100%'>
<tr>
<td width='15%' height='40px' align='center'><a href='feereceive.php'>Student Fee</a></td>
<td width='15%' height='40px' align='center'><a href='vouchers.php'>Payment Vouchers</a></td>
<td width='15%' height='40px' align='center'><a href='receiptvouchers.php'>Receipt Vouchers</a></td>
<td width='15%' height='40px' align='center'><a href='finevouchers.php'>Fine Vouchers</a></td>
<td width='15%' height='40px' align='center'><a href='advance.php'>Advance</a></td>
</tr>
<tr>

<td width='15%' height='40px' align='center'><a href='carryover.php'>Carry Over</a></td>
<td width='15%' height='40px' align='center'><a href='chequeclear.php'>Cheque Clearance</a></td>
<td width='15%' height='40px' align='center'>Under Development</td>
<td width='15%' height='40px' align='center'>Under Development</td>
<td width='15%' height='40px' align='center'>Under Development</td>
</tr>



</table>
</div> -->
</body>
</html>
<?php
include('../include/footer.php');
}?>
