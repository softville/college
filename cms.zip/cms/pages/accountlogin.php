<?php
session_start();
?>
<?php
include_once('../database/dbconnect.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <title>College Management System | Admin-Login</title>
  <meta name="description" content="Softvillle Technologies, Imagine the Possibilities">
  <meta name="keywords" content="college management,College Management,Website Designing,Web Application Development,Hosting,Logo,Logo Design,Digital Marketing,Market research,Website,HTML,CSS,XML,JavaScript,Bootstrap,C,C++,Photoshop,Coral Draw,AngularJS,jQuery,KnockoutJS,JSON,Java,.Net,LESS,Responsive,php,wordpress,CMS,Coaching,Institute,Software,Training,">
  <meta name="author" content="Softville Technologies">
  <meta name="viewport" content="width=device-width" initial-scale="1"/>
  <link rel="stylesheet" href="../css/bootstrap.min.css"/>
  <link rel="stylesheet" href="../css/login.css"/>
  <link rel="stylesheet" href="../css/font-awesome-4.6.3/css/font-awesome.min.css">



  <script src="../script/bootstrap.min.js"></script>
  <script type="text/javascript" src="../script/jquery.min.js"></script>
  <script type="text/javascript" src="../script/login.js"></script>
</head>
<body>
  <section class="container">
    <div class="row login-form text-center">
      <div class="col-sm-4 col-md-4 col-xs-4">
      </div>
      <div class="outer col-sm-6 col-md-6 col-xs-6 text-center">
        <span class="log-heading" style="padding-top:85px!important;height:150px!important"><div class="title">ADMIN&nbsp;LOGIN</div></span>
          <div class="inner">
            <div class="cms-icon"><i class="fa fa-graduation-cap fa-3x" aria-hidden="true"></i></div>
              <form role="form" name="" method="post" enctype="application/x-www-form-urlencoded">
                <div class="form-group">
                  <span class="log-inp-con">
                    <i class="fa fa-user-secret fa-2x icon"></i> &nbsp;<input type="text" name="username" class="log-txt" placeholder="USERNAME" required >
                  </span>
                </div>
                <div class="form-group">
                  <span class="log-inp-con"><i class="fa fa-key fa-2x icon"></i> <input type="password" name="password" class="log-txt" id="passtxt" placeholder="PASSWORD" required></span>
                </div>
                <div class="form-group">
                  <div class="row">
                    <div class="col-sm-5 col-xs-5 col-md-5 text-center"><span class="text-center shw"><input type="checkbox"/> &nbsp;show password</span></div>
                    <div class="col-sm-5 col-xs-5 col-md-5 text-center"><input type="submit" name="login" class="btn btn-primary but-sub" value="Submit" /></div>
                    <div class="col-sm-2 col-xs-2 text-center arrow"><i class=" text-center arr-icon icon fa fa-arrow-circle-down fa-2x" aria-hidden="true"></i></div>
                  </div>
                </div>
              </form>
          </div>
          <div class="login text center"><span class="admin"><a href="../index.php"><i class="fa fa-user" aria-hidden="true"></i> &nbsp;Login</a></span></div>
      </div>
      <div class="col-sm-3 col-md-3">
      </div>
    </div>
  </section>
</body>
</html>

<?php
if (isset($_POST['login'])){
	  $user = $_POST['username'];
	  $pass = $_POST['password'];
	$query4 = "select * from account_users where user_account='$user' AND password='$pass'";
	$run4 = mysql_query($query4);
	if(mysql_num_rows($run4)>0){

		$_SESSION['user']=$user;


	echo "<script>window.open('accountstudent.php','_self')</script>";
	}
	else{
	echo "<script>alert('Username or password Incorrect')</script>";
	}
}
?>
