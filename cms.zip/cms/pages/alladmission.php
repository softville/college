<?php
session_start();
if(!isset($_SESSION['username'])){

header("location:index.php");
}
else {
	?>

<?php
include('header.php');
include_once('database/dbconnect.php');
?>


<html>
<head>

<link rel="stylesheet" href="css/ui-lightness/jquery-ui-1.10.4.custom.css">
<link rel="stylesheet" type="text/CSS" href="style.css">
<script type="text/javascript" src="js/jquery-1.10.2.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.js"></script>

<div class="panel panel-primary">
                            <div class="panel-heading">
                                <h3 class="panel-title">Admission Cell Activity</h3>
                            </div>
                           
                        </div>

</head>
<body>
<div id='ccounts'>
<table class="table table-bordered">
<tr class="info">
<td width='15%' height='40px' align='center'><a href='addnew.php'>New Admission</a></td>
<td width='15%' height='40px' align='center'><a href='uploadcert.php'>Upload Certificates</a></td>
<td width='15%' height='40px' align='center'><a href='feedetailsearch.php'>Submit Fee Detail</a></td>
<td width='15%' height='40px' align='center'><a href='finedetails.php'>Submit Fine Detail</a></td>
<td width='15%' height='40px' align='center'><a href='documentsubmit.php'>Submit Document Detail</a></td>
</tr>
<tr class="success">
<td width='15%' height='40px' align='center'><a href='studentstatus.php'>Change Student Status</a></td>
<td width='15%' height='40px' align='center'><a href='studentsession.php'>Promote Students</a></td>
<td width='15%' height='40px' align='center'><a href='exadmission.php'>Ex Admission</a></td>
<td width='15%' height='40px' align='center'><a href='exfeedetail.php'>Submit Fee (Ex Admission)</a></td>
<td width='15%' height='40px' align='center'><a href='extoreg.php'>Convert Ex Add. into Regular</a></td>

</tr>
<tr class="danger">
<!--<td width='15%' height='40px' align='center'><a href='bushostelstatus#.php'>Update Bus or Hostel Fee</a></td>-->
<td width='15%' height='40px' align='center'><a href='addbushostel.php'>Add Bus or hostel</a></td>
<td width='15%' height='40px' align='center'><a href='#'>Under Development</a></td>
<td width='15%' height='40px' align='center'><a href='#'>Under Development</a></td>
<td width='15%' height='40px' align='center' colspan='5'><a href='#'>Under Development</a></td>

</tr>



</table>
</div>

</body>
</html>
<?php 
include('footer.php');
} ?>